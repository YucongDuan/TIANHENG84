from tianheng84.cli import main
raise SystemExit(main())
