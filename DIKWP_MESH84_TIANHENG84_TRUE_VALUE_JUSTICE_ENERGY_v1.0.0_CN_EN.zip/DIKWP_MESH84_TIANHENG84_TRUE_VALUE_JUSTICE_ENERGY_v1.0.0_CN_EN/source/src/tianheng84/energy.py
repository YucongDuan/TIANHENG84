from __future__ import annotations

def account(case,selected):
    t=case.get('telemetry') or {}; c=selected.get('costs') or {}; vv=selected.get('value_vector') or {}
    compute=t.get('compute_joules',c.get('compute_joules'))
    input_tokens=t.get('input_tokens'); output_tokens=t.get('output_tokens')
    att=float(c.get('attention_minutes',t.get('attention_minutes',0)) or 0)
    ver=float(c.get('verification_minutes',0) or 0)
    positive=sum(max(0,float(v)) for v in vv.values())
    negative=sum(max(0,-float(v)) for v in vv.values())
    info_gain=round(max(0,vv.get('truth',0))+max(0,vv.get('understanding',0))+max(0,vv.get('agency',0)),3)
    if compute is None: physical='UNMEASURED'
    else: physical={'joules':compute,'kwh':round(float(compute)/3600000,8)}
    status='POSITIVE' if positive>negative and info_gain>0.5 and vv.get('harm_reduction',0)>=0 and vv.get('justice',0)>=0 else 'OPEN_OR_NEGATIVE'
    return {'physical_energy':physical,'input_tokens':input_tokens,'output_tokens':output_tokens,'attention_minutes':att,'verification_minutes':ver,'positive_value_mass':round(positive,3),'negative_value_mass':round(negative,3),'validated_information_gain_proxy':info_gain,'net_value_status':status,'note_cn':'不同价值维度不可与焦耳直接相加。本账本记录物理成本与价值效果的并列证据，不声称违反能量守恒。'}
