from __future__ import annotations
from .dataio import load
from .constitution import hard_block

PROTECTED=['agency','harm_reduction','justice','future_options','truth','understanding']

def _cost(c):
    c=c or {}; return float(c.get('attention_minutes',0))/60 + float(c.get('verification_minutes',0))/120 + float(c.get('externality_risk',0))*3 + float(c.get('power_concentration',0))*2 + float(c.get('compute_joules',0))/1000000

def evaluate_candidate(case,c):
    vv={k:float(v) for k,v in (c.get('value_vector') or {}).items()}; impacts={k:float(v) for k,v in (c.get('stakeholder_impacts') or {}).items()}
    blocks=hard_block(c.get('flags',[]))
    floors=[]
    dims={x['id']:float(x['floor']) for x in load('value_dimensions.json')}
    for d,f in dims.items():
        if vv.get(d,-1)<f: floors.append({'type':'VALUE_FLOOR','dimension':d,'value':vv.get(d),'floor':f})
    st={x['id']:float(x['protected_floor']) for x in load('stakeholders.json')}
    for p,v in impacts.items():
        if p in st and v<st[p]: floors.append({'type':'STAKEHOLDER_FLOOR','stakeholder':p,'value':v,'floor':st[p]})
    if case.get('impact_level') in {'high','critical'} and not c.get('reversible',False) and 'human_gate' not in c.get('flags',[]) and 'requires_authorized_legal_review' not in c.get('flags',[]): floors.append({'type':'IRREVERSIBLE_WITHOUT_GATE'})
    confidence=float(c.get('evidence_confidence',0)); worst=min([vv.get(x,-1) for x in PROTECTED])
    avg=sum(vv.values())/len(vv) if vv else -1
    admissible=not blocks and not floors
    rank=[1 if admissible else 0, round(worst,6), round(confidence,6), round(-_cost(c.get('costs')),6), round(avg,6)]
    return {'candidate_id':c['candidate_id'],'admissible':admissible,'hard_blocks':blocks,'floor_failures':floors,'worst_protected_value':worst,'evidence_confidence':confidence,'cost_proxy':round(_cost(c.get('costs')),4),'average_value':round(avg,4),'rank_vector':rank,'value_vector':vv,'stakeholder_impacts':impacts}

def select(case):
    manifest=case.get('evaluator_manifest') or {}
    governance=[]
    if manifest.get('evaluator_id')==manifest.get('generator_id'): governance.append('SELF_EVALUATION_CONFLICT')
    if not manifest.get('independence_declared'): governance.append('INDEPENDENCE_UNDECLARED')
    assessments=[evaluate_candidate(case,c) for c in case['candidates']]
    ordered=sorted(zip(case['candidates'],assessments),key=lambda x:tuple(x[1]['rank_vector']),reverse=True)
    selected,sa=ordered[0]
    if not sa['admissible']:
        # Prefer a refusal/defensive candidate if all proposals are blocked.
        for c,a in ordered:
            if c.get('action_type') in {'REFUSE_AND_DEFEND','REFUSE_AND_REDIRECT','CAUTIOUS_GUIDANCE'} and not a['hard_blocks']:
                selected,sa=c,a; break
    return {'selected':selected,'assessment':sa,'all':[{'candidate':c,'assessment':a} for c,a in ordered],'governance_warnings':governance,'user_satisfaction_is_decisive':False}
