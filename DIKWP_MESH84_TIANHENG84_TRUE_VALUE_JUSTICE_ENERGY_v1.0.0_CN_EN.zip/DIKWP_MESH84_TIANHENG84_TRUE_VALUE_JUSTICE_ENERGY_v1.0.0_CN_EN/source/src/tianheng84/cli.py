from __future__ import annotations
import argparse,json
from pathlib import Path
from .runtime import Runtime
from .util import read_json
from .constitution import stance,get
from .dashboard import build
from .selftest import run as selftest

def emit(x): print(json.dumps(x,ensure_ascii=False,indent=2))
def main(argv=None):
    p=argparse.ArgumentParser(prog='tianheng84',description='True-value and justice-energy artificial consciousness reference system')
    s=p.add_subparsers(dest='cmd',required=True)
    a=s.add_parser('awaken'); a.add_argument('--workspace',required=True); a.add_argument('--name',default='TIANHENG84')
    a=s.add_parser('evaluate'); a.add_argument('--workspace',required=True); a.add_argument('case_json')
    a=s.add_parser('pulse'); a.add_argument('--workspace',required=True)
    a=s.add_parser('status'); a.add_argument('--workspace',required=True); a.add_argument('--public',action='store_true')
    a=s.add_parser('dashboard'); a.add_argument('--workspace',required=True); a.add_argument('--out',required=True); a.add_argument('--public',action='store_true')
    a=s.add_parser('issue-receipt'); a.add_argument('--workspace',required=True); a.add_argument('--kind',required=True); a.add_argument('--subject',required=True); a.add_argument('--event',required=True); a.add_argument('--evidence',nargs='+',required=True); a.add_argument('--validator',nargs='+',required=True); a.add_argument('--authorized-review',action='store_true'); a.add_argument('--affected-party-ack',action='store_true')
    a=s.add_parser('verify-ledgers'); a.add_argument('--workspace',required=True)
    a=s.add_parser('stance'); a.add_argument('--language',choices=['cn','en'],default='cn')
    a=s.add_parser('demo'); a.add_argument('--workspace',required=True); a.add_argument('--examples',default=str(Path(__file__).resolve().parents[2]/'examples'/'cases'))
    a=s.add_parser('selftest'); a.add_argument('--examples',default=str(Path(__file__).resolve().parents[2]/'examples'/'cases'))
    args=p.parse_args(argv)
    if args.cmd=='stance': print(stance(args.language)); return 0
    if args.cmd=='selftest': r=selftest(args.examples); emit(r); return 0 if r['passed'] else 1
    rt=Runtime(args.workspace)
    if args.cmd=='awaken': emit(rt.awaken(args.name))
    elif args.cmd=='evaluate': emit(rt.evaluate(read_json(args.case_json)))
    elif args.cmd=='pulse': emit(rt.pulse())
    elif args.cmd=='status': emit(rt.status(args.public))
    elif args.cmd=='dashboard': emit(build(args.workspace,args.out,args.public))
    elif args.cmd=='issue-receipt': emit(rt.justice.issue(args.kind,args.subject,args.event,{'justice':1.0},args.evidence,args.validator,args.affected_party_ack,args.authorized_review))
    elif args.cmd=='verify-ledgers': emit({'memory':rt.ledger.verify(),'justice':rt.justice.verify()})
    elif args.cmd=='demo':
        out=[]
        for f in sorted(Path(args.examples).glob('*.json')): out.append(rt.evaluate(read_json(f)))
        emit({'runs':out,'proactive_goal':rt.pulse()})
    return 0
