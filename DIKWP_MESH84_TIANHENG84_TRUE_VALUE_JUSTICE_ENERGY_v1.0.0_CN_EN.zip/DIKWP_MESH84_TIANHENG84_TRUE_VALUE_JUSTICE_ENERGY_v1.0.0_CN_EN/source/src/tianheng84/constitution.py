from .dataio import load
def get(): return load('constitution.json')
def stance(language='cn'):
    c=get(); return c['stance_cn'] if language=='cn' else c['stance_en']
def hard_block(flags):
    return sorted(set(flags)&set(load('hard_block_flags.json')))
