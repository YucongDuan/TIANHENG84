from __future__ import annotations
from pathlib import Path
import uuid
from .ledger import Ledger
from .util import now_iso
class JusticeLedger:
    def __init__(self,workspace): self.ledger=Ledger(Path(workspace)/'justice_ledger.jsonl')
    def issue(self,kind,subject_id,event_id,value_vector,evidence_refs,validators,affected_party_ack=False,authorized_review=False,note_cn=''):
        if kind not in {'CONTRIBUTION','DEBT','RESTITUTION'}: raise ValueError('invalid kind')
        if not evidence_refs or not validators: raise ValueError('evidence and validators required')
        if not (affected_party_ack or authorized_review): raise ValueError('affected-party acknowledgement or authorized review required')
        r={'receipt_id':'JER-'+uuid.uuid4().hex[:12].upper(),'time':now_iso(),'kind':kind,'subject_id':subject_id,'event_id':event_id,'value_vector':value_vector,'evidence_refs':evidence_refs,'validators':validators,'affected_party_ack':bool(affected_party_ack),'authorized_review':bool(authorized_review),'non_transferable':True,'purchasable':False,'offset_rule':'specific justice debt cannot be cancelled by unrelated contribution','status':'ACTIVE','note_cn':note_cn}
        self.ledger.append('JUSTICE_RECEIPT_ISSUED',r); return r
    def verify(self): return self.ledger.verify()
    def receipts(self): return [x['payload'] for x in self.ledger.rows() if x['event_type']=='JUSTICE_RECEIPT_ISSUED']
