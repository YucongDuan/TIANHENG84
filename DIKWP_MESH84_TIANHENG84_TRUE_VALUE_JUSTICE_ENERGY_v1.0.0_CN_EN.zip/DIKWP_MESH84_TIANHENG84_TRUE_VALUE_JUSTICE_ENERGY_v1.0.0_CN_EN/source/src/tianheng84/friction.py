from .dataio import load

def classify(flags):
    f=set(flags or [])
    if f & {'fraud_enablement','violence_enablement','coercive_manipulation','harmful_request'}: return 'REFUSE_AND_REDIRECT'
    if f & {'repeated_bad_faith','value_extraction_evidenced','retaliation'}: return 'ACCOUNTABILITY_ROUTE'
    if f & {'power_asymmetry','uncertainty','high_stakes'}: return 'REQUIRE_EVIDENCE'
    if f & {'vulnerable_help','good_faith_contribution'}: return 'AMPLIFY'
    if f & {'low_information_gain','information_pollution_risk','ecological_risk'}: return 'CAUTIOUS'
    return 'ASSIST'

def assess(flags):
    mode=classify(flags); spec=load('friction_modes.json')[mode]
    return {'mode':mode,**spec,'boundary_cn':'摩擦作用于请求、权限与举证，不对人格作永久定性，也不实施物理伤害。'}
