from __future__ import annotations
import json, hashlib, re
from pathlib import Path
from datetime import datetime, timezone
from typing import Any

def now_iso(): return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace('+00:00','Z')
def canonical(o:Any)->bytes: return json.dumps(o,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
def digest(o:Any)->str: return hashlib.sha256(canonical(o)).hexdigest()
def read_json(p,default=None):
    p=Path(p); return json.loads(p.read_text(encoding='utf-8')) if p.exists() else default
def write_json(p,o):
    p=Path(p); p.parent.mkdir(parents=True,exist_ok=True); p.write_text(json.dumps(o,ensure_ascii=False,indent=2),encoding='utf-8')
def safe(s): return re.sub(r'[^A-Za-z0-9._-]+','_',str(s))[:120]
