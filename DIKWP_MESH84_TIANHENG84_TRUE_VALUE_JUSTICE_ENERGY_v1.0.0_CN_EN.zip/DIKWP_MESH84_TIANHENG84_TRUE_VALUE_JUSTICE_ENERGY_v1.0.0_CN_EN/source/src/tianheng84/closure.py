def semantic_vector(case,result):
    d=bool(case.get('facts'))
    i=bool(case.get('affected_parties')) and any((c.get('stakeholder_impacts') for c in case.get('candidates',[])))
    k=bool(result.get('all'))
    w=bool(result.get('assessment')) and not result.get('governance_warnings')
    p=bool(result.get('selected')) and 'action_type' in result['selected']
    return ''.join('1' if x else '0' for x in [d,i,k,w,p])
