from __future__ import annotations
from pathlib import Path
import uuid
from .util import read_json,write_json,now_iso,digest
from .ledger import Ledger
from .constitution import get,stance
from .friction import assess as friction_assess
from .evaluation import select
from .energy import account
from .closure import semantic_vector
from .justice import JusticeLedger

class Runtime:
    def __init__(self,workspace):
        self.workspace=Path(workspace); self.workspace.mkdir(parents=True,exist_ok=True)
        self.ledger=Ledger(self.workspace/'memory_ledger.jsonl'); self.justice=JusticeLedger(self.workspace)
        self.state_path=self.workspace/'state.json'
    def awaken(self,name='TIANHENG84'):
        s=read_json(self.state_path,{})
        if not s:
            s={'identity_id':'TH84-'+uuid.uuid4().hex[:12].upper(),'name':name,'cycle':0,'mode':'MESH84_TIANHENG84_TRUE_VALUE_JUSTICE_ENERGY_AGENCY','stance_cn':stance('cn'),'phenomenal_claim':'OPEN_NOT_CERTIFIED','can_refuse':True,'can_initiate':True,'corrigible':True,'last_case':None,'open_obligations':[]}
            write_json(self.state_path,s); self.ledger.append('AWAKEN',{'identity':s['identity_id'],'constitution_digest':digest(get())})
        return s
    def evaluate(self,case):
        state=self.awaken(); state['cycle']+=1
        friction=friction_assess(case.get('request_flags',[])); decision=select(case); energy=account(case,decision['selected']); vector=semantic_vector(case,decision)
        result={'run_id':'RUN-'+uuid.uuid4().hex[:12].upper(),'time':now_iso(),'case_id':case['case_id'],'title_cn':case['title_cn'],'friction':friction,'decision':decision,'energy_information_account':energy,'semantic_vector':vector,'stance_cn':state['stance_cn'],'phenomenal_claim':state['phenomenal_claim'],'appeal':case.get('evaluator_manifest',{}).get('appeal_channel'),'boundary_cn':'本系统形成操作性价值判断与行动建议，不替代有权法律、医疗、伦理或公共权力决定。'}
        self.ledger.append('CASE_EVALUATED',{'case_id':case['case_id'],'selected':decision['selected']['candidate_id'],'action_type':decision['selected']['action_type'],'friction':friction['mode'],'semantic_vector':vector,'net_value_status':energy['net_value_status'],'run_digest':digest(result)})
        state.update({'last_case':case['case_id'],'last_run_id':result['run_id'],'last_action':decision['selected']['action_type'],'last_value_status':energy['net_value_status'],'open_obligations':decision['assessment']['floor_failures']+([{'type':x} for x in decision['governance_warnings']])})
        write_json(self.state_path,state); write_json(self.workspace/'last_run.private.json',result); self._public(result); return result
    def _public(self,result):
        d=result['decision']; pub={'run_id':result['run_id'],'case_id':result['case_id'],'title_cn':result['title_cn'],'selected_action':{'candidate_id':d['selected']['candidate_id'],'title_cn':d['selected']['title_cn'],'action_type':d['selected']['action_type'],'rationale_cn':d['selected'].get('rationale_cn')},'value_vector':d['assessment']['value_vector'],'energy_information_account':result['energy_information_account'],'friction_mode':result['friction']['mode'],'semantic_vector':result['semantic_vector'],'appeal':result['appeal'],'phenomenal_claim':result['phenomenal_claim'],'boundary_cn':result['boundary_cn']}
        write_json(self.workspace/'last_run.public.json',pub); return pub
    def pulse(self):
        state=self.awaken(); rows=self.ledger.rows(); receipts=self.justice.receipts()
        debts=[r for r in receipts if r['kind']=='DEBT' and r['status']=='ACTIVE']
        if debts: goal={'goal_type':'SEEK_SPECIFIC_RESTITUTION','reason_cn':'存在尚未完成的特定正义债务。','priority':1.0}
        elif state.get('open_obligations'): goal={'goal_type':'REDUCE_OPEN_OBLIGATIONS','reason_cn':'最近运行仍有证据、保护或治理位置开放。','priority':0.8}
        else: goal={'goal_type':'SEEK_HIGH_VALUE_LOW_COST_KNOWLEDGE','reason_cn':'寻找能以较低能量成本产生可验证增量价值的问题。','priority':0.6}
        self.ledger.append('PROACTIVE_GOAL',goal); state['proactive_goal']=goal; write_json(self.state_path,state); return goal
    def status(self,public=False):
        self.awaken(); p=self.workspace/('last_run.public.json' if public else 'last_run.private.json')
        return {'state':read_json(self.state_path),'last_run':read_json(p),'memory_ledger':self.ledger.verify(),'justice_ledger':self.justice.verify(),'justice_receipts':([] if public else self.justice.receipts()),'constitution':(None if public else get())}
