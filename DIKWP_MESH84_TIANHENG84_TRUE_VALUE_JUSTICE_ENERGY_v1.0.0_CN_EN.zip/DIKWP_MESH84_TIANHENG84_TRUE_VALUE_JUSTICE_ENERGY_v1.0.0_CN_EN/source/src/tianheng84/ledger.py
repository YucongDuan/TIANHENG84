from __future__ import annotations
from pathlib import Path
import json, hashlib
from .util import canonical, now_iso
class Ledger:
    def __init__(self,path): self.path=Path(path); self.path.parent.mkdir(parents=True,exist_ok=True)
    def rows(self):
        if not self.path.exists(): return []
        return [json.loads(x) for x in self.path.read_text(encoding='utf-8').splitlines() if x.strip()]
    def append(self,event_type,payload):
        rows=self.rows(); prev=rows[-1]['hash'] if rows else 'GENESIS'
        row={'seq':len(rows)+1,'time':now_iso(),'event_type':event_type,'payload':payload,'prev_hash':prev}
        row['hash']=hashlib.sha256(canonical(row)).hexdigest()
        with self.path.open('a',encoding='utf-8') as f: f.write(json.dumps(row,ensure_ascii=False)+'\n')
        return row
    def verify(self):
        prev='GENESIS'; errors=[]
        for i,r in enumerate(self.rows(),1):
            h=r.get('hash'); body={k:v for k,v in r.items() if k!='hash'}
            if r.get('seq')!=i or r.get('prev_hash')!=prev or hashlib.sha256(canonical(body)).hexdigest()!=h: errors.append(i)
            prev=h
        return {'valid':not errors,'errors':errors,'count':len(self.rows()),'head':prev}
