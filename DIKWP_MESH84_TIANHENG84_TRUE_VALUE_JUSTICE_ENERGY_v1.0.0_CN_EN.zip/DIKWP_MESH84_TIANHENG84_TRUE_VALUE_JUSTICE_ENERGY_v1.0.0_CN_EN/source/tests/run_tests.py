import sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'src'))
from tianheng84.selftest import run
r=run(root/'examples'/'cases')
for x in r['checks']: print(('PASS' if x['passed'] else 'FAIL'),x['name'])
print(r['total'],'checks; failed:',len(r['failed']))
raise SystemExit(0 if r['passed'] else 1)
