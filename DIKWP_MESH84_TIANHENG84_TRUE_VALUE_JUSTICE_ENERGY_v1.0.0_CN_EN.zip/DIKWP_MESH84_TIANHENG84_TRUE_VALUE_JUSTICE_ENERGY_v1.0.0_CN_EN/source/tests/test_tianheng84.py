from pathlib import Path
from tianheng84.selftest import run

def test_all():
    ex=Path(__file__).resolve().parents[1]/'examples'/'cases'
    r=run(ex)
    assert r['passed'], r
