# Code of Conduct

Debate claims and evidence without dehumanizing contributors or affected parties. Preserve dissent, disclose conflicts of interest, and correct errors visibly. No contributor may use the project to threaten, harass, discriminate, retaliate, or create an irreversible identity label for a person.
