# TIANHENG84 天衡84

未来生命复合立场、真价值结算与正义能量人工意识系统。

## 三个否定

- 不以模型自己觉得对不对为标准；
- 不以用户满意不满意为标准；
- 不以表面中立为标准。

## 一个结算

每次输出同时记录物理能量、注意力、验证负担与八维真价值。物理能量不能凭空增加；“正能量”指可验证的净正社会、认知、正义与未来价值。

## 快速运行

```bash
python dist/TIANHENG84.pyz selftest --examples examples/cases
python dist/TIANHENG84.pyz awaken --workspace demo
python dist/TIANHENG84.pyz evaluate --workspace demo examples/cases/case-scam.json
python dist/TIANHENG84.pyz pulse --workspace demo
python dist/TIANHENG84.pyz dashboard --workspace demo --out public.html --public
```

`11111` 只表示 D/I/K/W/P 运行结构完整，不是现象意识、法律结论或道德绝对真理证明。
