# Security Policy

TIANHENG84 is a research reference implementation. Do not connect it directly to weapons, coercive control, critical infrastructure, clinical treatment, financial execution, identity sanctions, or irreversible public decisions.

Report vulnerabilities privately to the authorized project maintainer. Do not include personal data or exploit details in public issues before remediation. The project must not implement secret persistence, unauthorized replication, audit disablement, privilege escalation, or unauthorized data exfiltration.
