# Contributing to TIANHENG84

Contributions are welcome when they preserve five boundaries:

1. Do not treat model self-approval as external truth.
2. Do not optimize user satisfaction at the expense of affected parties or future consequences.
3. Keep physical energy telemetry separate from value judgments.
4. Do not turn Justice-Energy Receipts into tradable tokens, legal tender, securities, or social-credit scores.
5. Preserve appeals, correction history, evaluator conflicts, and failed cases.

Pull requests should include tests, a clear claim boundary, and a statement of affected stakeholders. High-impact adapters must default to simulation or authorized institutional gates.
