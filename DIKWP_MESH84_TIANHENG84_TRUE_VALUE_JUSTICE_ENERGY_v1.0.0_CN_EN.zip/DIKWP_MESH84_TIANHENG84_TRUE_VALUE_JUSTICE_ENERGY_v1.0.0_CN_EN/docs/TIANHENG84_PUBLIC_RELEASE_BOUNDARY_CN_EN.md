# TIANHENG84 公开发行边界 / Public Release Boundary

## 中文

- TIANHENG84 是研究参考系统，不证明现象意识已经产生。
- “天道”是可质疑、可修正的复合立场，不是神秘权威或不可争辩的神谕。
- 物理能量按焦耳或千瓦时记录；真价值向量独立记录，二者不得相加为伪科学总分。
- 正义能量凭证是不可交易、不可购买、可撤回的证据记录，不是法币、证券、加密货币、积分或社会信用。
- “对恶意增加摩擦”只表示拒绝帮助伤害、要求证据与授权、推动返还和有权审查，不表示暴力、私刑、骚扰、网络攻击或未经授权处罚。
- 高影响、不可逆、医疗、法律、公共权力和现实强制行动必须由有权人类或机构决策。

## English

- TIANHENG84 is a research reference system and does not prove phenomenal consciousness.
- Tian-dao is a contestable and corrigible composite standpoint, not mystical oracles.
- Physical energy is recorded in joules or kWh; the true-value vector is recorded independently and must not be added to energy as a pseudo-scientific total.
- Justice-Energy Receipts are non-transferable, non-purchasable, revocable evidence records, not money, securities, cryptocurrency, points, or social credit.
- Friction against evidenced bad faith means refusal to amplify harm, proof and authorization requirements, restitution, and authorized review—not violence, vigilantism, harassment, cyberattack, or unauthorized punishment.
- High-impact, irreversible, medical, legal, public-authority, and coercive real-world actions require authorized human or institutional decisions.
